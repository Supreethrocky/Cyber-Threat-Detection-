import os

SECRET_KEY = os.urandom(24)
MONGO_URI = "mongodb://localhost:27017/cti_dashboard"
VIRUSTOTAL_API_KEY = "ac13e45e191044d03522052929761c7fd7ed07dec21050d6e36bc15f84751c7d"
ABUSEIPDB_API_KEY = "638e9fc061dbe5c1602e32ccfcc55eb5039d974e8d3298748c57bc580c20f52a0ea6855958f896e9"


# Redis and Celery Configuration
REDIS_URL = "redis://localhost:6379/0"
CELERY_BROKER_URL = REDIS_URL
CELERY_RESULT_BACKEND = REDIS_URL
# config.py

# ... (your existing settings) ...

# Celery Beat Schedule
CELERYBEAT_SCHEDULE = {
    'poll-threats-every-30-seconds': {
        'task': 'tasks.poll_threat_feeds',  # The name of the task to run
        'schedule': 30.0,                  # Run every 30 seconds
    },
}