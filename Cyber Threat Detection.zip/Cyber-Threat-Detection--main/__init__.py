# __init__.py
from flask import Flask
from extensions import mongo, socketio, celery
import tasks  # <--- ADD THIS LINE

def create_app():
    app = Flask(__name__)
    # ... (rest of the file is exactly the same) ...
    app.config.from_pyfile('config.py')

    mongo.init_app(app)
    socketio.init_app(app)

    celery.conf.update(
        broker_url=app.config['CELERY_BROKER_URL'],
        result_backend=app.config['CELERY_RESULT_BACKEND']
    )
    celery.conf.update(app.config)

    class ContextTask(celery.Task):
        def __call__(self, *args, **kwargs):
            with app.app_context():
                return self.run(*args, **kwargs)
    celery.Task = ContextTask
    
    with app.app_context():
        import routes
        app.register_blueprint(routes.main)

    return app