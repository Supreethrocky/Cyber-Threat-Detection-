# tasks.py
import random
from extensions import celery, socketio
# IMPORT from utils.py, NOT routes.py
from utils import query_abuseipdb, process_abuseipdb_data

# A list of known malicious IPs to simulate a "live feed"
KNOWN_THREAT_IPS = [
    "185.220.101.4", "91.219.29.55", "198.54.117.199",
    "172.67.139.117", "104.21.23.149"
]

@celery.task(name='tasks.poll_threat_feeds')
def poll_threat_feeds():
    """This background task simulates finding a new threat."""
    print("LIVE FEED: Polling for new threats...")
    indicator = random.choice(KNOWN_THREAT_IPS)
    print(f"LIVE FEED: Found new indicator: {indicator}")

    # The Flask app context is needed to access current_app.config for API keys
    from __init__ import create_app
    app = create_app()
    with app.app_context():
        abuseipdb_results = query_abuseipdb(indicator)

        if abuseipdb_results:
            processed_data = process_abuseipdb_data(abuseipdb_results)
            if processed_data:
                print(f"LIVE FEED: Pushing {indicator} to dashboards via WebSocket.")
                socketio.emit('new_threat_data', {
                    'source': 'Live Threat Feed', 
                    'data': processed_data
                })
                
                if processed_data.get('latitude'):
                    socketio.emit('new_geo_threat', processed_data)

    return f"Polling complete for {indicator}."