# routes.py
from flask import Blueprint, render_template
import models
from extensions import socketio
from utils import (  # <-- IMPORT from our new utils.py file
    query_virustotal,
    query_abuseipdb,
    process_vt_data,
    process_abuseipdb_data
)

main = Blueprint('main', __name__)

# --- Page Routes ---
@main.route('/')
def dashboard():
    return render_template('index.html')

@main.route('/investigations')
def investigations():
    return render_template('investigations.html')

@main.route('/reports')
def reports():
    return render_template('reports.html')

@main.route('/threat_models')
def threat_models():
    return render_template('threat_models.html')

@main.route('/settings')
def settings():
    return render_template('settings.html')

# --- WebSocket Event Handlers ---
@socketio.on('lookup_indicator')
def handle_lookup_event(json_data):
    """Handles the lookup event from the client via WebSocket."""
    indicator = json_data.get('indicator')
    if not indicator:
        return

    socketio.emit('status_update', {'message': f'Querying APIs for {indicator}...'})
    
    vt_results = query_virustotal(indicator)
    if vt_results:
        models.save_threat_data(indicator, 'VirusTotal', vt_results)
        processed_vt = process_vt_data(vt_results, indicator)
        if processed_vt:
            socketio.emit('new_threat_data', {'source': 'VirusTotal', 'data': processed_vt})
    
    abuseipdb_results = query_abuseipdb(indicator)
    if abuseipdb_results:
        models.save_threat_data(indicator, 'AbuseIPDB', abuseipdb_results)
        processed_abuse = process_abuseipdb_data(abuseipdb_results)
        if processed_abuse:
            if processed_abuse.get('latitude'):
                socketio.emit('new_geo_threat', processed_abuse)
            socketio.emit('new_threat_data', {'source': 'AbuseIPDB', 'data': processed_abuse})

    socketio.emit('status_update', {'message': 'Lookup complete.'})