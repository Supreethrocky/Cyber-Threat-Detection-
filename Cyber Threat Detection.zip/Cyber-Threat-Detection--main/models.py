# models.py
from extensions import mongo # Direct import
from datetime import datetime
import pymongo

# (The rest of the file is unchanged)
# ... paste the full content from the previous answer here ...
def save_threat_data(indicator, source, data):
    existing_record = mongo.db.threats.find_one({'indicator': indicator, 'source': source, 'timestamp': {'$gte': datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)}})
    if existing_record:
        mongo.db.threats.update_one({'_id': existing_record['_id']}, {'$set': {'data': data, 'timestamp': datetime.utcnow()}})
        return existing_record['_id']
    else:
        threat = {'indicator': indicator, 'source': source, 'data': data, 'timestamp': datetime.utcnow(), 'tags': []}
        result = mongo.db.threats.insert_one(threat)
        return result.inserted_id

def get_threats_by_indicator(indicator):
    return list(mongo.db.threats.find({'indicator': indicator}))

def get_recent_threats(limit=50):
    return list(mongo.db.threats.find().sort('timestamp', pymongo.DESCENDING).limit(limit))

def add_tag_to_threat(threat_id, tag):
    mongo.db.threats.update_one({'_id': threat_id}, {'$addToSet': {'tags': tag}})

def get_threat_trends():
    pipeline = [{"$group": {"_id": {"year": {"$year": "$timestamp"}, "month": {"$month": "$timestamp"}, "day": {"$dayOfMonth": "$timestamp"}}, "count": {"$sum": 1}}}, {"$sort": {"_id": 1}}]
    return list(mongo.db.threats.aggregate(pipeline))